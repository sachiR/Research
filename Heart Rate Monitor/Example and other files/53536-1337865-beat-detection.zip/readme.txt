Beat detection--------------
Url     : http://codes-sources.commentcamarche.net/source/53536-beat-detectionAuteur  : barsichouDate    : 01/08/2013
Licence :
=========

Ce document intitul� � Beat detection � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Bonjour,
<br />Ce programme pour Windows qui utilise FMOD permet de d&eacute;te
cter le tempo d'une musique en MP3, et aussi de construire une &quot;beat line&q
uot; (un tableau de la taille de la musique qui contient quelque chose quand il 
y a un beat et 0 ailleurs). Il y a une interface graphique SFML dont je me suis 
servi pour d&eacute;bugger.
<br />
<br />Pour calculer le tempo, je me suis in
spir&eacute; en partie de &ccedil;a:
<br /><a href='http://www.flipcode.com/mis
c/BeatDetectionAlgorithms.pdf' target='_blank'>http://www.flipcode.com/misc/Beat
DetectionAlgorithms.pdf</a>
<br />
<br />En gros l'algo c'est:
<br />On calcu
l &agrave; tout moment (tous les 1024 samples) l'&eacute;nergie du signal. L'&ea
cute;nergie &eacute;tant la somme des &eacute;chantillons au carr&eacute;. (Pour
 une fr&eacute;quence d'&eacute;chantillonnage de 44100 Hertz ou Samples/seconde
, 1024 samples c'est 1/43 eme de seconde et c'est quasi instantan&eacute; pour l
'oreille.
<br />(La courbe verte dans l'interface)
<br />On calcul ensuite l'&
eacute;nergie moyenne sur une seconde entourant chaque instant.
<br />(La courb
e bleu dans l'interface)
<br />A chaque fois que l'&eacute;nergie instantan&eac
ute;e d&eacute;passe d'une constante * l'&eacute;nergie moyenne, on a un beat pr
obable. La constante est environ 1,3. Si la musique est bruyante &ccedil;a sera 
un peu moins, Elle peut &ecirc;tre variable et calcul&eacute;e &agrave; tout mom
ent automatiquement  avec un calcul de variance mais je ne l'ai pas fais ici.
<
br />(Les rectangles blancs dans l'interface)
<br />Apr&egrave;s on comptabilis
e les espaces de temps entre tous ces beats probables et celui qui revient le pl
us souvent nous donne le tempo.
<br />Ensuite on peut faire une convolution ave
c un train d'impulsion de quelques secondes et de la m&ecirc;me fr&eacute;quence
 que le tempo trouv&eacute;, &Ccedil;a permet de rester &laquo;�sur les rails�&r
aquo; quand il y a des pauses par exemple.
<br />(La courbe jaune dans l'interf
ace)
<br />Les pics de la convolution qui surviennent &agrave; peu pr&egrave;s 
au bon tempo nous donne la Beat line
<br />(Les traits verts fonc&eacute; dans 
l'interface)
<br />
<br />librairies: FMOD EX, SFML 1,6
<br />
<br />Pour le
 lancer, faire un glisser-d&eacute;poser d'un fichier .mp3 directement sur le .e
xe
<br />Pour man�uvrer dans l'interface, les instructions sont affich&eacute;e
s &agrave; l'ex&eacute;cution.
<br /><a name='source-exemple'></a><h2> Source /
 Exemple : </h2>
<br /><pre class='code' data-mode='basic'>
// dans le zip
<
/pre>
<br /><a name='conclusion'></a><h2> Conclusion : </h2>
<br />voici une 
vid&eacute;o de ce que ca donne:
<br /><a href='http://www.youtube.com/watch?v=
jZoQ1S73Bac' target='_blank'>http://www.youtube.com/watch?v=jZoQ1S73Bac</a>
<br
 />La baballe qui saute c'est juste pour le fun.
<br />&Eacute;videment je n'ai
 mis que des exemples qui marchent mais c'est loin d'&ecirc;tre toujours le cas.
 Mais pour tout ce qui est musique &eacute;nergique avec des beats r&eacute;guli
ers, &ccedil;a passe. 
<br />Si le tempo trouv&eacute; est trop rapide, il suff
it des fois d'augmenter un peu la constante K_ENERGIE_RATIO, et de la baisser si
 c'est trop lent.
<br />Pour que &ccedil;a marche plus souvent, on peut faire p
lein de truc, notamment d&eacute;couper en plages de fr&eacute;quences mais &cce
dil;a complexifie pas mal. A voir pour la suite.
